<h2>Dashboard</h2>

<div class="info">Selamat datang, <strong>ISI NAMA</strong></div>